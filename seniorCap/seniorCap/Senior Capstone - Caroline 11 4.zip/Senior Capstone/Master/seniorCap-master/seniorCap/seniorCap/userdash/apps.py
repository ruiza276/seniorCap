from django.apps import AppConfig


class UserdashConfig(AppConfig):
    name = 'userdash'
